
document.getElementById("formReciclagem").addEventListener("submit", function(e) {
    alert("Formulário enviado com sucesso!");
});
